export const BUN = 'bun';
export const SAUCE = 'sauce';
export const MAIN = 'main';
export const ITEM = 'item';