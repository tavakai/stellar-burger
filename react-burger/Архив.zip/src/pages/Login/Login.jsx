import { Input, ShowIcon, HideIcon, Button } from '@ya.praktikum/react-developer-burger-ui-components';
import styles from './Login.module.css';
import { useState } from "react";

const Login = () => {
  const [value, setValue] = useState('value')

  return (
    <section className={styles.section}>
      <div>
        <form action="/" className={styles.from}>
          <fieldset>
          <legend>Вход</legend>
            <Input
            type={'text'}
            placeholder={'placeholder'}
            value='email'
            onChange={e => setValue(e.target.value)}
            />
            <Input
            type={'text'}
            placeholder={'placeholder'}
            value='password'
            onChange={e => setValue(e.target.value)}
            />
          </fieldset>
          <Button />
        </form>
        <p>Вы - новый пользователь? <a href="#">Зарегистрироваться</a></p>
        <p>Забыли пароль? <a href="#">Восстановить пароль</a></p>
      </div>
    </section>
  )
}

export default Login;