import { useDispatch, useSelector } from 'react-redux';
import AppHeader from '../AppHeader/AppHeader';
import style from './App.module.css';
import Modal from '../Modal/Modal';
import IngredientDetails from '../IngredientDetails/IngredientDetails';
import OrderDetails from '../OrderDetails/OrderDetails';
import { hideModal } from '../../services/actions/index';
import Preloader from '../Preloader/Preloader';
import { Routes, Route, Link, useLocation, useNavigate } from 'react-router-dom';
import Login from '../../pages/Login/Login';
import Layout from '../Layout/Layout';
import IngredientPage from '../../pages/IngredientPage/IngredientPage';
import { useEffect } from 'react';

function App() {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { modal, currentIngredient } = useSelector(store => store.ingredients);
  const { orderRequest } = useSelector(store => store.order);
  const location = useLocation();
  const background = location.state && location.state.background;

  const handleHideModal = () => {
    dispatch(hideModal())
    navigate.goBack();
  }

  useEffect(() => {
    console.log(location.state)
  }, [location])
  

  return (
    <div className={style.App}>
      <AppHeader />
      <main className={style.main}>
        <Routes location={background || location}>
          <Route path='/' element={<Layout />} />
          <Route path='/login' element={<Login />} />
          <Route path='/ingredients/:id' element={<IngredientPage />} />
        </Routes>
        {
          background && modal && currentIngredient &&
          <Routes>
            <Route path='/ingredients/:id' element={
              <Modal show={modal} hideModal={handleHideModal} header >
                <IngredientDetails />
              </Modal>
            } />
          </Routes>
        }
        {
          orderRequest ? (
            <Preloader />
          ) : (
            modal && !currentIngredient &&
            <Modal show={modal} hideModal={handleHideModal} header >
              <OrderDetails />
            </Modal>
          )
        }
      </main>
    </div>
  );
}

export default App;
